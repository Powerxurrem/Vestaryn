export function hasValidAssistantContract(text: string) {
  const s = String(text ?? "");

  const hasTriplet =
    s.startsWith("[Observation]") ||
    (
      s.includes("[Observation]") &&
      s.includes("[Assessment]") &&
      s.includes("[Action]")
    );

  const hasProposalMarkers =
    s.includes("__PROPOSAL__:") ||
    s.includes("__PROPOSAL_SET__:") ||
    s.includes("__APPLY__:") ||
    s.includes("__APPLY_SET__:");

  return hasTriplet || hasProposalMarkers;
}



