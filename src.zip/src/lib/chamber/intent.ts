export function extractMentionedPaths(text: string) {
  return Array.from(
    new Set(
      (
        text.match(/[A-Za-z0-9_./\-[\]]+\.[A-Za-z0-9]+/g) ?? []
      ).map((s) => s.trim())
    )
  );
}

export function extractSingleMentionedPath(text: string) {
  const paths = extractMentionedPaths(text || "");
  return paths.length === 1 ? paths[0] : null;
}

export function isNamedFileExecutionRequest(text: string) {
  return (
    /check|correct|fix|debug|resolve|repair|rewrite|improve|refactor|clean up|cleanup|harden|modify|edit|update|review|inspect|turn|transform|convert|evolve/i.test(
      text || ""
    ) && extractMentionedPaths(text || "").length >= 1
  );
}

export function isRepositoryExecutionIntent(text: string) {
  return /create|add|render|use|insert|implement|refine|improve|rewrite|clean up|cleanup|harden|extend|modify|edit|tighten|fix|update|replace|check|correct|review|inspect|debug|repair|resolve|turn|transform|convert|evolve/i.test(
    text || ""
  );
}

export function isCreateAndModifyIntent(text: string) {
  return /create|add|implement/i.test(text || "") &&
         /render|use|import|insert|mount/i.test(text || "");
}